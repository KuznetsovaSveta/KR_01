package com.metanit;
//Задание 1_1
//public class Main {
//
//    public static void main(String[] args) {
//        System.out.println( "Silence is golden" );
//    }
//}



//Задание 1_3
//public class Main {
//
//    public static void main(String[] args) {
//        System.out.println( "0" );
//        System.out.println( "00" );
//        System.out.println( "000" );
//        System.out.println( "0000" );
//        System.out.println( "00000" );
//    }
//}


//Задание 2_11
//import java.util.Scanner;
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println( "Введите количество дней: ");
//        int days = scanner.nextInt();
//        System.out.println( "Введите процент скидки: ");
//        float percent = scanner.nextInt();;
//        System.out.println( "Введите сумму: ");
//        float sum = scanner.nextInt();
//
//        percent /= 100;
//        for (int i = 0; i <= days; i++){
//            sum += 3;
//            sum += sum * percent;
//        }
//        System.out.println( "Итоговая сумма = " + sum);
//    }
//}



//Задание 2_17
//import java.util.Scanner;
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        int a = scanner.nextInt();
//        int f;//для подсчета а в 4 степени
//        int b;//для подсчета а в 6 степени
//        int c;//для подсчета а в 15 степени
//        int d;//для подсчета а в 15 степени
//        int e;//для подсчета а в 15 степени
//        int result;
//        f = a * a;
//        f = a * a;
//        System.out.println( "a в четвертой степени = " + f);
//        b = a * a;
//        b = b * a;
//        b = b * b;
//        System.out.println( "a в шестой степени = " + b);
//        b = a * a;
//        c = b * a;
//        d = c * c;
//        e = d * d;
//        a = c * e;
//        System.out.println( "a в пятнадцатой степени = " + a);
//    }
//}



//Задание 3_11
//import java.util.Scanner;
//public class Main {
//
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        int first = scanner.nextInt();
//        int second = scanner.nextInt();
//        int result;
//
//        if((first != 10) && (second != 10) && (first %2 == 0)) {
//            result = first + second;
//            System.out.println("Результат: " + result);
//        }
//        else{
//            result = first * second;
//            System.out.println("Результат: " + result);
//        }
//
//
//    }
//}




//Задание 3_37
//import java.util.Scanner;
//public class Main {
//
//    public static void main(String[] args) {
//
//        Scanner scanner = new Scanner(System.in);
//        int k = scanner.nextInt();
//
//        String str = "1112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899";
//        char result = str.charAt(k);
//        System.out.println("Результат: " + result);
//    }
//}



//Задание 4_11
//public class Main {
//
//    public static void main(String[] args) {
//        int result = 1;
//
//        for (int i = 5; i <= 13; i++){
//            result = result * i;
//        }
//        System.out.println("Результат: " + result);
//    }
//}


//Задание 4_42
//public class Main {
//    public static void main(String[] args) {
//        int k = 57846;
//        int result = 0;
//
//        while (k != 0) {
//            result += k % 10;
//            k /= 10;
//            if (k != 0) {
//                result *= 10;
//            }
//        }
//        System.out.println(result);
//    }
//}





//Задание 5_2
//public class Main {
//    public static void main(String[] args) {
//        int d = 0;
//        for (char i = 'a'; i <= 'z'; i++)
//        {
//            if(d % 5 == 0 && d!=0){
//                System.out.print ("\n" + " " + i + " ");
//            }
//            else{
//                System.out.print (" " + i + " ");
//            }
//            d++;
//        }
//    }
//}

//Задание 5_5
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        String[] line;
        line = new String[rnd(3, 10)];
        for (int i = 0; i < line.length; i++){
            line[i] = Character.toString(rnd(97,122));
        }
        line[rnd(0, line.length - 1)] = "!";
        line[rnd(0, line.length - 1)] = "!";
        System.out.println(arrayToString(line));
    }

    public static String arrayToString(String[] s) {
        StringBuilder result = new StringBuilder();
        for (String value : s) result.append(value);
        return result.toString();
    }

    public static int rnd(int min, int max) {
        max -= min;
        return (int) (Math.random() * ++max) + min;
    }
}
